package sarmabaruaabhigyan_OOP_05;

//The PRSI interface
public interface PRSI {
	static final double rate = 0.04; 		//As 4% = 0.04
	public abstract double calculatePRSI();		//Abstract method
}
