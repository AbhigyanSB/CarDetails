package sarmabaruaabhigyan_OOP_05;

//The taxable interface
public interface Taxable {
	public abstract double calculateTax();		//Method to calculate tax
	public abstract void printTax();		//Method to print tax
}
